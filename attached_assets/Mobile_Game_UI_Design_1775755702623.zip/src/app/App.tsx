import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ResourceBar } from './components/ResourceBar';
import { CorruptionScale } from './components/CorruptionScale';
import { EventPopup } from './components/EventPopup';
import { SkillsTree } from './components/SkillsTree';
import { BottomNav } from './components/BottomNav';

export default function App() {
  const [activeTab, setActiveTab] = useState('life');
  const [showEvent, setShowEvent] = useState(false);

  // Player stats
  const [money, setMoney] = useState(150);
  const [health, setHealth] = useState(75);
  const [reputation, setReputation] = useState(50);
  const [corruption, setCorruption] = useState(30);
  const [workClicks, setWorkClicks] = useState(0);

  // Skills
  const [skills, setSkills] = useState([
    { id: 'oratory', name: 'Oratory', icon: '🗣️', level: 1, maxLevel: 5, cost: 100, description: 'Persuade others with eloquent speech' },
    { id: 'bribery', name: 'Bribery', icon: '💸', level: 0, maxLevel: 5, cost: 150, description: 'Grease palms to get what you want' },
    { id: 'haggling', name: 'Haggling', icon: '🤝', level: 2, maxLevel: 5, cost: 80, description: 'Negotiate better deals at market' },
    { id: 'farming', name: 'Farming', icon: '🌾', level: 3, maxLevel: 5, cost: 120, description: 'Grow crops more efficiently' },
    { id: 'networking', name: 'Networking', icon: '👥', level: 0, maxLevel: 5, cost: 200, description: 'Build connections with influential people' },
  ]);

  const event = {
    title: 'A Neighbor Asks for a "Favor"',
    description: 'Your neighbor wants you to help him get a permit faster by "talking" to the right official. He offers you ₴200.',
    choices: {
      honest: 'Honest Path',
      corrupt: 'Corrupt Deal'
    }
  };

  const handleWork = () => {
    const earnedMoney = 20 + (skills.find(s => s.id === 'farming')?.level || 0) * 5;
    setMoney(prev => prev + earnedMoney);
    setHealth(prev => Math.max(0, prev - 5));
    setWorkClicks(prev => prev + 1);

    // Random event trigger
    if (Math.random() > 0.7) {
      setTimeout(() => setShowEvent(true), 500);
    }
  };

  const handleChoice = (choice: 'honest' | 'corrupt') => {
    if (choice === 'honest') {
      setReputation(prev => Math.min(100, prev + 10));
      setCorruption(prev => Math.max(0, prev - 5));
      setMoney(prev => prev + 50);
    } else {
      setMoney(prev => prev + 200);
      setCorruption(prev => Math.min(100, prev + 15));
      setReputation(prev => Math.max(0, prev - 5));
    }
    setShowEvent(false);
  };

  const handleUpgrade = (skillId: string) => {
    const skill = skills.find(s => s.id === skillId);
    if (!skill || skill.level >= skill.maxLevel || money < skill.cost) return;

    setMoney(prev => prev - skill.cost);
    setSkills(prev => prev.map(s =>
      s.id === skillId ? { ...s, level: s.level + 1, cost: Math.floor(s.cost * 1.5) } : s
    ));
  };

  return (
    <div className="size-full flex flex-col bg-[#e8dcc4] overflow-hidden max-w-md mx-auto">
      {/* Top Stats Bar */}
      <div className="bg-[#8b4513] border-b-4 border-[#2a1f0f] p-3 space-y-2 shadow-lg">
        <div className="grid grid-cols-3 gap-2">
          <ResourceBar icon="₴" value={money} maxValue={999} color="#ffd700" label="Money" />
          <ResourceBar icon="❤️" value={health} maxValue={100} color="#ff4444" label="Health" />
          <ResourceBar icon="⭐" value={reputation} maxValue={100} color="#ffaa00" label="Rep" />
        </div>
        <CorruptionScale value={corruption} />
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        <AnimatePresence mode="wait">
          {activeTab === 'life' && (
            <motion.div
              key="life"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              {/* Character & Khata Section */}
              <div
                className="relative h-80 bg-cover bg-center border-b-4 border-[#2a1f0f]"
                style={{
                  backgroundImage: 'url(https://images.unsplash.com/photo-1653775174351-ec93b874097d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1a3JhaW5pYW4lMjB2aWxsYWdlJTIwaG91c2V8ZW58MXx8fHwxNzc1NzUzMTUzfDA&ixlib=rb-4.1.0&q=80&w=1080)',
                  backgroundPosition: 'center 35%'
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-[#2a1f0f]/60 via-transparent to-transparent" />

                {/* Character */}
                <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-center">
                  <motion.div
                    animate={{ y: [0, -10, 0] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                    className="text-7xl mb-2"
                  >
                    🧑‍🌾
                  </motion.div>

                  <motion.button
                    onClick={handleWork}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="bg-gradient-to-b from-[#8b4513] to-[#654321] text-[#fff8e7] px-8 py-4 border-4 border-[#2a1f0f] rounded-sm font-black uppercase tracking-wider shadow-2xl relative overflow-hidden"
                    style={{
                      fontFamily: 'Russo One, sans-serif',
                      textShadow: '2px 2px 4px rgba(0,0,0,0.5)'
                    }}
                  >
                    <div className="absolute inset-0 opacity-30"
                         style={{
                           backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 2px, rgba(255,255,255,0.1) 2px, rgba(255,255,255,0.1) 4px)'
                         }}
                    />
                    <span className="relative">💪 WORK</span>
                  </motion.button>
                </div>

                {/* Work counter */}
                {workClicks > 0 && (
                  <div className="absolute top-4 right-4 bg-[#2a1f0f] text-[#ffd700] px-3 py-2 border-2 border-[#ffd700] rounded-sm">
                    <div className="text-xs font-black" style={{ fontFamily: 'Rubik, sans-serif' }}>
                      Shifts: {workClicks}
                    </div>
                  </div>
                )}
              </div>

              {/* Info Section */}
              <div className="p-4 space-y-3">
                <div className="bg-[#f5ede0] border-2 border-[#8b4513] p-4 rounded-sm relative overflow-hidden"
                     style={{
                       backgroundImage: 'url("data:image/svg+xml,%3Csvg width="20" height="20" xmlns="http://www.w3.org/2000/svg"%3E%3Cpath d="M0 0h20v20H0z" fill="none"/%3E%3Cpath d="M10 0L0 20h20z" fill="%23d4a574" opacity="0.1"/%3E%3C/svg%3E")',
                       backgroundSize: '40px 40px'
                     }}>
                  <h3 className="font-black text-lg mb-2 uppercase" style={{ fontFamily: 'Russo One, sans-serif' }}>
                    🏠 Your Journey Begins
                  </h3>
                  <p className="text-sm leading-relaxed" style={{ fontFamily: 'Rubik, sans-serif' }}>
                    Start from humble beginnings in a village khata. Work the land, make tough choices, and navigate the complex path to success. Will you stay honest or embrace the corruption that surrounds you?
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-[#8b6f47] text-[#fff8e7] p-3 border-2 border-[#2a1f0f] rounded-sm text-center">
                    <div className="text-2xl mb-1">🌾</div>
                    <div className="text-xs font-black uppercase" style={{ fontFamily: 'Russo One, sans-serif' }}>Village Life</div>
                  </div>
                  <div className="bg-[#654321] text-[#ffd700] p-3 border-2 border-[#2a1f0f] rounded-sm text-center">
                    <div className="text-2xl mb-1">🏆</div>
                    <div className="text-xs font-black uppercase" style={{ fontFamily: 'Russo One, sans-serif' }}>Aim High</div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'work' && (
            <motion.div
              key="work"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="p-4 space-y-3"
            >
              <div className="bg-[#8b4513] text-[#fff8e7] px-4 py-3 -rotate-1 border-2 border-[#2a1f0f] shadow-lg">
                <h2 className="font-black uppercase tracking-wide text-center" style={{ fontFamily: 'Russo One, sans-serif' }}>
                  💼 Work Opportunities 💼
                </h2>
              </div>

              <div className="space-y-3">
                {['Farm Labor', 'Construction', 'Market Vendor', 'Delivery Driver'].map((job, i) => (
                  <motion.div
                    key={job}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="bg-[#f5ede0] border-2 border-[#2a1f0f] p-4 rounded-sm"
                  >
                    <h3 className="font-black mb-1" style={{ fontFamily: 'Rubik, sans-serif' }}>{job}</h3>
                    <p className="text-xs text-[#5d4e37] mb-2">Earn ₴{15 + i * 10}/shift</p>
                    <button className="w-full bg-[#8b4513] text-[#fff8e7] py-2 border-2 border-[#2a1f0f] font-black text-sm uppercase rounded-sm"
                            style={{ fontFamily: 'Russo One, sans-serif' }}>
                      Start Shift
                    </button>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'business' && (
            <motion.div
              key="business"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="p-4"
            >
              <div className="bg-[#8b4513] text-[#fff8e7] px-4 py-3 -rotate-1 border-2 border-[#2a1f0f] shadow-lg mb-4">
                <h2 className="font-black uppercase tracking-wide text-center" style={{ fontFamily: 'Russo One, sans-serif' }}>
                  🏢 Business Ventures 🏢
                </h2>
              </div>
              <div className="bg-[#f5ede0] border-2 border-[#2a1f0f] p-6 text-center rounded-sm">
                <div className="text-5xl mb-3">🔒</div>
                <p className="font-black text-lg mb-2" style={{ fontFamily: 'Russo One, sans-serif' }}>LOCKED</p>
                <p className="text-sm text-[#5d4e37]" style={{ fontFamily: 'Rubik, sans-serif' }}>
                  Unlock business opportunities by earning ₴500
                </p>
              </div>
            </motion.div>
          )}

          {activeTab === 'skills' && (
            <motion.div
              key="skills"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <SkillsTree skills={skills} onUpgrade={handleUpgrade} playerMoney={money} />
            </motion.div>
          )}

          {activeTab === 'market' && (
            <motion.div
              key="market"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="p-4 space-y-3"
            >
              <div className="bg-[#8b4513] text-[#fff8e7] px-4 py-3 -rotate-1 border-2 border-[#2a1f0f] shadow-lg">
                <h2 className="font-black uppercase tracking-wide text-center" style={{ fontFamily: 'Russo One, sans-serif' }}>
                  🛒 Market Goods 🛒
                </h2>
              </div>

              {[
                { name: 'Bread', price: 10, icon: '🍞' },
                { name: 'Medical Kit', price: 50, icon: '💊' },
                { name: 'Vodka', price: 30, icon: '🍶' },
                { name: 'Work Boots', price: 80, icon: '🥾' }
              ].map((item, i) => (
                <motion.div
                  key={item.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-[#f5ede0] border-2 border-[#2a1f0f] p-4 rounded-sm flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{item.icon}</span>
                    <div>
                      <h3 className="font-black" style={{ fontFamily: 'Rubik, sans-serif' }}>{item.name}</h3>
                      <p className="text-xs text-[#5d4e37]">₴{item.price}</p>
                    </div>
                  </div>
                  <button
                    disabled={money < item.price}
                    className="bg-[#8b4513] text-[#fff8e7] px-4 py-2 border-2 border-[#2a1f0f] font-black text-xs uppercase rounded-sm disabled:opacity-50"
                    style={{ fontFamily: 'Russo One, sans-serif' }}
                  >
                    Buy
                  </button>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom Navigation */}
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Event Popup */}
      <EventPopup
        isOpen={showEvent}
        onClose={() => setShowEvent(false)}
        event={event}
        onChoice={handleChoice}
      />
    </div>
  );
}
