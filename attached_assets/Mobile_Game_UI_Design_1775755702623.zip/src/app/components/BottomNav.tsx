import { motion } from "motion/react";

interface NavItem {
  id: string;
  label: string;
  icon: string;
}

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tabId: string) => void;
}

const navItems: NavItem[] = [
  { id: 'life', label: 'Life', icon: '🏠' },
  { id: 'work', label: 'Work', icon: '💼' },
  { id: 'business', label: 'Business', icon: '🏢' },
  { id: 'skills', label: 'Skills', icon: '📚' },
  { id: 'market', label: 'Market', icon: '🛒' },
];

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  return (
    <div className="bg-[#8b4513] border-t-4 border-[#2a1f0f] shadow-2xl">
      <div className="flex items-stretch justify-around">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className="flex-1 relative py-3 px-2 transition-all hover:bg-[#654321]"
            >
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-[#654321]"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.4 }}
                />
              )}
              <div className="relative flex flex-col items-center gap-1">
                <span className="text-2xl">{item.icon}</span>
                <span
                  className="text-[10px] font-black uppercase tracking-wider"
                  style={{
                    fontFamily: 'Russo One, sans-serif',
                    color: isActive ? '#ffd700' : '#fff8e7'
                  }}
                >
                  {item.label}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
