interface ResourceBarProps {
  icon: string;
  value: number;
  maxValue: number;
  color: string;
  label: string;
}

export function ResourceBar({ icon, value, maxValue, color, label }: ResourceBarProps) {
  const percentage = (value / maxValue) * 100;

  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-center gap-1.5">
        <span className="text-xl">{icon}</span>
        <div className="flex-1 h-6 bg-[#4a3520] rounded-sm border-2 border-[#2a1f0f] relative overflow-hidden shadow-inner">
          <div
            className="h-full transition-all duration-300 relative"
            style={{
              width: `${percentage}%`,
              background: `linear-gradient(180deg, ${color} 0%, ${color}dd 100%)`
            }}
          >
            <div className="absolute inset-0 opacity-20"
                 style={{
                   backgroundImage: 'repeating-linear-gradient(90deg, transparent, transparent 2px, rgba(0,0,0,0.1) 2px, rgba(0,0,0,0.1) 4px)'
                 }}
            />
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-xs font-black text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]" style={{ fontFamily: 'Rubik, sans-serif' }}>
              {value}/{maxValue}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
