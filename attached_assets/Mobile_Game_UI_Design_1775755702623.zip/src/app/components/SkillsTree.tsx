import { motion } from "motion/react";

interface Skill {
  id: string;
  name: string;
  icon: string;
  level: number;
  maxLevel: number;
  cost: number;
  description: string;
}

interface SkillsTreeProps {
  skills: Skill[];
  onUpgrade: (skillId: string) => void;
  playerMoney: number;
}

export function SkillsTree({ skills, onUpgrade, playerMoney }: SkillsTreeProps) {
  return (
    <div className="flex flex-col gap-3 p-4">
      <div className="bg-[#8b4513] text-[#fff8e7] px-4 py-3 -rotate-1 border-2 border-[#2a1f0f] shadow-lg mb-2">
        <h2 className="font-black uppercase tracking-wide text-center" style={{ fontFamily: 'Russo One, sans-serif' }}>
          💡 Skills & Abilities 💡
        </h2>
      </div>

      {skills.map((skill, index) => (
        <motion.div
          key={skill.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.05 }}
          className="bg-[#f5ede0] border-2 border-[#2a1f0f] p-4 rounded-sm shadow-md relative overflow-hidden"
          style={{
            backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(212,165,116,0.1) 10px, rgba(212,165,116,0.1) 20px)'
          }}
        >
          <div className="flex items-start gap-3">
            <div className="text-3xl bg-[#d4a574] border-2 border-[#2a1f0f] rounded-full w-14 h-14 flex items-center justify-center flex-shrink-0">
              {skill.icon}
            </div>

            <div className="flex-1">
              <div className="flex items-start justify-between mb-1">
                <h3 className="font-black uppercase" style={{ fontFamily: 'Rubik, sans-serif' }}>
                  {skill.name}
                </h3>
                <div className="bg-[#2a1f0f] text-[#ffd700] px-2 py-0.5 rounded text-xs font-black" style={{ fontFamily: 'Rubik, sans-serif' }}>
                  {skill.level}/{skill.maxLevel}
                </div>
              </div>

              <p className="text-xs text-[#5d4e37] mb-2" style={{ fontFamily: 'Rubik, sans-serif' }}>
                {skill.description}
              </p>

              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 bg-[#4a3520] rounded-full border border-[#2a1f0f] overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#ffd700] to-[#ffaa00]"
                    style={{ width: `${(skill.level / skill.maxLevel) * 100}%` }}
                  />
                </div>

                <button
                  onClick={() => onUpgrade(skill.id)}
                  disabled={skill.level >= skill.maxLevel || playerMoney < skill.cost}
                  className="bg-gradient-to-b from-[#8b4513] to-[#654321] text-[#ffd700] px-3 py-1 border-2 border-[#2a1f0f] rounded-sm font-black text-xs uppercase disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105 active:scale-95 transition-transform shadow-md"
                  style={{ fontFamily: 'Russo One, sans-serif' }}
                >
                  ₴{skill.cost}
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
