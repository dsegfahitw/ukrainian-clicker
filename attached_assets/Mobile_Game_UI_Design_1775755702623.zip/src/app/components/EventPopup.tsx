import { motion, AnimatePresence } from "motion/react";
import { X } from "lucide-react";

interface EventPopupProps {
  isOpen: boolean;
  onClose: () => void;
  event: {
    title: string;
    description: string;
    choices: {
      honest: string;
      corrupt: string;
    };
  };
  onChoice: (choice: 'honest' | 'corrupt') => void;
}

export function EventPopup({ isOpen, onClose, event, onChoice }: EventPopupProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 z-40 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[90%] max-w-md"
          >
            <div className="bg-[#f5ede0] border-4 border-[#2a1f0f] rounded-lg p-6 shadow-2xl relative"
                 style={{
                   backgroundImage: 'url("data:image/svg+xml,%3Csvg width="100" height="100" xmlns="http://www.w3.org/2000/svg"%3E%3Cpath d="M0 0h100v100H0z" fill="%23f5ede0"/%3E%3Cpath d="M50 0v100M0 50h100" stroke="%23e8dcc4" stroke-width="1"/%3E%3C/svg%3E")',
                   backgroundSize: '50px 50px'
                 }}>
              <button
                onClick={onClose}
                className="absolute top-3 right-3 p-1 hover:bg-[#d4a574] rounded transition-colors"
              >
                <X size={20} />
              </button>

              <div className="text-center mb-6">
                <div className="inline-block bg-[#8b4513] text-[#fff8e7] px-4 py-2 -rotate-1 mb-4 border-2 border-[#2a1f0f]">
                  <h3 className="font-black uppercase tracking-wide" style={{ fontFamily: 'Russo One, sans-serif' }}>
                    ⚠️ Life Event ⚠️
                  </h3>
                </div>
                <p className="font-bold mb-2" style={{ fontFamily: 'Rubik, sans-serif' }}>
                  {event.title}
                </p>
                <p className="text-sm text-[#5d4e37]" style={{ fontFamily: 'Rubik, sans-serif' }}>
                  {event.description}
                </p>
              </div>

              <div className="space-y-3">
                <button
                  onClick={() => onChoice('honest')}
                  className="w-full bg-gradient-to-b from-[#4a9d5f] to-[#3d7d4f] text-white py-4 px-4 border-3 border-[#2a1f0f] rounded-sm font-black uppercase tracking-wide shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-transform relative overflow-hidden"
                  style={{
                    fontFamily: 'Russo One, sans-serif',
                    textShadow: '2px 2px 4px rgba(0,0,0,0.5)'
                  }}
                >
                  <div className="absolute inset-0 opacity-20"
                       style={{
                         backgroundImage: 'linear-gradient(45deg, transparent 40%, rgba(255,255,255,0.3) 50%, transparent 60%)',
                         backgroundSize: '200% 200%'
                       }}
                  />
                  <span className="relative">✓ {event.choices.honest}</span>
                </button>

                <button
                  onClick={() => onChoice('corrupt')}
                  className="w-full bg-gradient-to-b from-[#8b4513] to-[#654321] text-[#ffd700] py-4 px-4 border-3 border-[#2a1f0f] rounded-sm font-black uppercase tracking-wide shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-transform relative overflow-hidden"
                  style={{
                    fontFamily: 'Russo One, sans-serif',
                    textShadow: '2px 2px 4px rgba(0,0,0,0.5)'
                  }}
                >
                  <div className="absolute inset-0 opacity-20"
                       style={{
                         backgroundImage: 'linear-gradient(45deg, transparent 40%, rgba(255,215,0,0.3) 50%, transparent 60%)',
                         backgroundSize: '200% 200%'
                       }}
                  />
                  <span className="relative">💰 {event.choices.corrupt}</span>
                </button>
              </div>

              <div className="mt-4 text-center text-xs text-[#5d4e37] italic" style={{ fontFamily: 'Rubik, sans-serif' }}>
                Your choice will affect your stats and path...
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
