interface CorruptionScaleProps {
  value: number;
}

export function CorruptionScale({ value }: CorruptionScaleProps) {
  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-center gap-2">
        <span className="text-lg">🤝</span>
        <div className="flex-1 h-6 bg-gradient-to-r from-green-600 via-yellow-500 to-red-700 rounded-sm border-2 border-[#2a1f0f] relative overflow-hidden shadow-lg">
          <div
            className="absolute top-0 bottom-0 w-1 bg-white border border-black transition-all duration-500"
            style={{ left: `${value}%` }}
          >
            <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-b-4 border-l-transparent border-r-transparent border-b-white" />
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-[10px] font-black text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]" style={{ fontFamily: 'Rubik, sans-serif' }}>
              CORRUPTION
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
